//
//  pokeViewController.swift
//  poke
//
//  Created by 玉利恒一 on 2019/02/10.
//  Copyright © 2019 tamari. All rights reserved.
//

import UIKit

class pokeViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    @IBAction func cancelTapped(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    

}
