//
//  CoreDateHelper.swift
//  poke
//
//  Created by 玉利恒一 on 2019/02/21.
//  Copyright © 2019 tamari. All rights reserved.
//

//import UIKit
//import CoreData
//
//func addAllPokemon() {
//
//}
//
//func getAllPokemon() -> [Pokemon] {
//    if let context = (UIApplication.shared.delegate as? APPdelegate)?.persistentContainer.viewContext{
//        if let pokemonData = try? context.feth(Pokemon.fetchRequest()) as? [Pokemon] {
//            if let pokemons = pokemonData{
//                if pokemons.count = 0{
//                    addAllPokemon()
//                    getAllPokemon()
//                    return getAllPokemon()
//                }else{
//                    return pokemons
//                }
//            }
//
//        }
//    }
//    return []
//}
